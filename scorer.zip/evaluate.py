# ==================================================================================
# PACKAGES
# ==================================================================================
# Standard
import logging

# Third Party
import pyspark
# ==================================================================================
# LOGGER
# ==================================================================================
logger = logging.getLogger(__name__)
# ==================================================================================
# LOCAL
# ==================================================================================
import mlfeatures as mlf
import supplementary as supp
# ==================================================================================
# CLASSES
# ==================================================================================
class Evaluator(mlf.ModelProcessor):
    '''
    Evaluator of Binary Classification Models
    
    :param multi_eval: MultiClass Evaluator Instance
    :type multi_eval: pyspark.ml.evaluation.MulticlassClassificationEvaluator
    :param bin_eval: Binary Evaluator Instance
    :type bin_eval: pyspark.ml.evaluation.BinaryClassificationEvaluator
    '''
    def __init__(self, multi_eval=None, bin_eval=None, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
        self.multi_eval = multi_eval
        self.bin_eval = bin_eval

    def build_multi_eval(self, target_col=None, pred_col='prediction'):
        '''
        Creates a multiclass evaluator
        to calc the following metrics:
        accuracy, f1-score, weighted Precision,
        weightedRecall
        
        :param target_col: Column with target labels
        :type target_col: str
        :param pred_col: Column with predictions,
            defaults to prediction
        :type pred_col: str
        '''
        from pyspark.ml.evaluation import MulticlassClassificationEvaluator
        
        if target_col is None:
            target_col = self.config['spine']['target_col']
        
        evaluator_multi = MulticlassClassificationEvaluator(labelCol=target_col,
                                                            predictionCol=pred_col)
        self.multi_eval = evaluator_multi
        
    def build_bin_eval(self, target_col=None, pred_col='rawprediction'):
        '''
        Creates a multiclass evaluator
        to calc the following metrics:
        accuracy, f1-score, weighted Precision,
        weightedRecall
        
        :param target_col: Column with target labels
        :type target_col: str
        :param target_col: Column with binary 0/1 prediction
            or probability of label 1, defaults to rawPrediction
        :type target_col: str
        '''
        from pyspark.ml.evaluation import BinaryClassificationEvaluator
        
        if target_col is None:
            target_col = self.config['spine']['target_col']
        
        bin_eval = BinaryClassificationEvaluator(labelCol=target_col,
                                                 rawPredictionCol=pred_col,
                                                 metricName='areaUnderROC')

        self.bin_eval = bin_eval
        
    def get_metrics(self, split='pred'):
        '''
        Evaluate dataset
        
        :param split: Indicator to which dataset evaluate 
            defaults to 'pred' (all data)
        :type split: str
        :return: Accuracy, f1-score, weighted Precision,
            weightedRecall, AUC and Coeficient Gini
        :rtype: pandas.DataFrame
        '''
        import pandas as pd
        import pyspark.sql.functions as f
        from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator

        eval_crit = ['accuracy', 'f1', 'weightedPrecision', 'weightedRecall']
        metrics_names = ['accuracy', 'f1-score', 'weighted_precision', 'weighted_recall', 'roc_auc', 'coef_gini']
        
        if split == 'train':
            df = self._train
        elif split == 'test':
            df = self._test
        elif split == 'val':
            df_val = self._val
            date_col = self.config['spine']['date_col']
            
            row_dates = df_val.select(date_col).orderBy(f.col(date_col)).distinct().collect()
            val_dates = [row[0] for row in row_dates]
            df = []
            for date in val_dates:
                df.append(df_val.filter(f.col(date_col) == date))
        else:
            df = self.data

        if isinstance(df, list):
            val_metrics = []
            for data in df:
                metrics = []
                for metric in eval_crit:
                    metrics.append(self.multi_eval.evaluate(data, {self.multi_eval.metricName: metric}))
                metrics.append(self.bin_eval.evaluate(data))
                metrics.append(2*metrics[-1] - 1)
                val_metrics.append(metrics)
                
            dict_data = {'metric_name': metrics_names}
            for date, prfce in zip(val_dates, val_metrics):
                dict_data[f'{split}_'+date.replace('-', '')] = prfce
        else:        
            metrics = []
            for metric in eval_crit:
                metrics.append(self.multi_eval.evaluate(df, {self.multi_eval.metricName: metric}))
            metrics.append(self.bin_eval.evaluate(df))
            metrics.append(2*metrics[-1] - 1)
            
            dict_data = {'metric_name': metrics_names, split: metrics}
        
        pd_metrics = pd.DataFrame(dict_data)
        
        return pd_metrics

    def get_KS(self, split=None, score_col=None, target_col=None, id_col=None,
               error=None, buckets=None, buckets_name=None):
        '''
        Separate observations into percentiles by propension,
        low deciles mean a higher prop and calculate
        performance over its scores - Uplift, KS.

        :param split: Indicator to which dataset evaluate 
            defaults to 'pred' (all data)
        :type split: str
        :param score_col: Column that contains score info
        :type score_col: str
        :param target_col: Binary column with target info
        :type target_col: str
        :param id_col: Identification column to count over
        :type id_col: str
        :param error: The relative target precision when 
            calculating deciles
        :type error: float
        :param buckets: Number of bins to discretize
        :type buckets: float
        :param buckets_name: Number of bins to discretize
        :type buckets_name: str
        :return: Dataframe with evaluation dy bins
        :rtype: pyspark.sql.DataFrame
        '''
        import pandas as pd
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        from pyspark.ml.feature import QuantileDiscretizer
        from pyspark.sql import Window

        if split == 'train':
            df = self._train
        elif split == 'test':
            df = self._test
        elif split == 'val':
            df = self._val
        else:
            df = self.data
        
        if score_col is None:
            score_col = self.config['score_col']
        if target_col is None:
            target_col = self.config['spine']['target_col']
        if id_col is None:
            id_col = self.config['spine']['artf_id_col']
        if error is None:
            error = self.config['eval']['error']
        if buckets is None:
            buckets = self.config['eval']['buckets']
        if buckets_name is None:
            buckets_name = self.config['buckets_name']

        if buckets_name not in df.columns:
            # Guarantee an even decile without any
            # major change in the scores
            df = df.withColumn('jitter', f.row_number().over(Window.orderBy(f.col(score_col).desc(), f.rand(seed=2012))))

            discretizer = QuantileDiscretizer(numBuckets=buckets,
                                              inputCol='jitter',
                                              outputCol=buckets_name,
                                              relativeError=error,
                                              handleInvalid='error')
            df = discretizer.fit(df).transform(df)
            df = df.withColumn(buckets_name, (f.col(buckets_name) + 1).cast(t.IntegerType()))

        # Totals
        target_total = df.filter(f.col(target_col) == 1).count()
        client_total = df.count()
        zero_total = client_total - target_total
        prior = target_total / client_total

        df_eval = df.groupBy(buckets_name) \
                    .agg(f.count(id_col).alias('Sum_Ids'),
                         f.sum(target_col).alias('TARGET'),
                         (f.sum(target_col) / f.count(id_col)).alias('Ratio_TARGET'),
                         f.min(score_col).alias('Min_Score'),
                         f.max(score_col).alias('Max_Score'),
                         f.avg(score_col).alias('Avg_Score'),
                         (f.sum(target_col) / f.lit(target_total)).alias('Percentage_of_TARGET'),   # Event rate
                         ((f.sum(target_col) / f.count(id_col)) / f.lit(prior)).alias('Uplift'),
                         ((f.count(id_col) - f.sum(target_col)) / f.lit(zero_total)).alias('non_event_rate')) \
                                                                            .orderBy(f.col(buckets_name).desc())
        # Window Functions to calc cummulatives
        window_spec = (Window.orderBy(f.col(buckets_name)) \
                             .rowsBetween(Window.unboundedPreceding, Window.currentRow))
        df_eval = df_eval.select(*[col for col in df_eval.columns],
                                 f.sum('Sum_Ids').over(window_spec).alias('Sum_Ids_Accum'),
                                 f.sum('TARGET').over(window_spec).alias('TARGET_Accum'),
                                 (f.sum('TARGET').over(window_spec) / f.sum('Sum_Ids').over(window_spec)).alias('Ratio_TARGET_Accum'),
                                 f.sum('Percentage_of_TARGET').over(window_spec).alias('Percentage_of_TARGET_Accum'),
                                 ((f.sum('TARGET').over(window_spec) / f.sum('Sum_Ids').over(window_spec)) / f.lit(prior)) \
                                                                                                       .alias('Uplift_Accum'),
                                 f.sum('non_event_rate').over(window_spec).alias('cumsum_non_event_rate'),
                                 f.round((f.sum('Percentage_of_TARGET').over(window_spec) - f.sum('non_event_rate') \
                                                                          .over(window_spec)), 4).alias('ks'))

        df_eval = df_eval.drop('non_event_rate', 'cumsum_non_event_rate')
        stat_cols = [buckets_name, 'Sum_Ids', 'TARGET', 'Sum_Ids_Accum', 'TARGET_Accum',
                     'Ratio_TARGET', 'Ratio_TARGET_Accum', 'Percentage_of_TARGET',
                     'Percentage_of_TARGET_Accum', 'Min_Score', 'Max_Score', 'Avg_Score',
                     'Uplift', 'Uplift_Accum', 'ks']

        df_eval = df_eval.select(*stat_cols)
        #pd_eval = df_eval.toPandas()

        return df_eval
        