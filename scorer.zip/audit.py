# ==================================================================================
# PACKAGES
# ==================================================================================
# Standard
import logging

# Third Party
import pandas
import pyspark
# ==================================================================================
# LOGGER
# ==================================================================================
logger = logging.getLogger(__name__)
# ==================================================================================
# LOCAL
# ==================================================================================
import mlfeatures as mlf
import supplementary as supp
# ==================================================================================
# CLASSES
# ==================================================================================
class Auditor:
    '''
    Monitoring and Auditing data
    '''
    
    @staticmethod
    def audit_varnum(df: pyspark.sql.DataFrame, date_eval, not_eval: list = []) -> pandas.DataFrame:
        '''
        Export unformarted excel file with summary statistics
        of numerical variables.

        :param df: Dataframe to analyze
        :type df: pyspark.sql.DataFrame
        :param date_eval: Date in the format '%Y-%m-%d'
        :type date_eval: str
        :param not_eval: List of columns not to include
            in the analysis
        :type not_eval: list
        :return: Dataframe with summary statistics
        :rtype: pandas.DataFrame
        '''
        import pandas as pd
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        from functools import reduce
        from pyspark.sql import Window

        def _get_mode(df):
            '''
            Get % that the most frequent level represents
            in the whole variable
            '''
            from pyspark.sql import Window
            import pyspark.sql.functions as f
            import pyspark.sql.types as t

            stack_string = ', '.join([f"\'{v}\', {v}" for v in df.columns])
            df_mode = df.select(f.expr(f'stack({len(df.columns)}, {stack_string}) as (COLUMN, LEVEL)')) \
                        .groupBy('COLUMN', 'LEVEL').count()

            count_rows = df.count()
            win = Window().partitionBy('COLUMN').orderBy(f.col('count').desc())
            df_mode = df_mode.withColumn('row_num', f.row_number().over(win)) \
                                    .where(f.col('row_num') == 1) \
                                    .drop('row_num') \
                                    .select(f.col('COLUMN').alias('feature'), f.col('LEVEL').alias('mode'))

            return df_mode   

        num_cols = [field.name for field in df.schema.fields if not isinstance(field.dataType, t.StringType)]
        num_cols = [col for col in num_cols if col not in not_eval]

        df_n = df.select(f.lit('n').alias('summary'),
                      *[f.count('*').alias(col) for col in num_cols])

        n_rows_total = df.count()
        df_miss = df.select(*[f.count(f.when(f.isnan(col) | f.col(col).isNull(), col)).alias(col) for col in num_cols])
        df_miss = df_miss.select(f.lit('pct_miss').alias('summary'),
                                 *[(f.col(col) / f.lit(n_rows_total)).alias(col) for col in num_cols])    

        df_zero = df.select(*[f.count(f.when(f.col(col) == 0, col)).alias(col) for col in num_cols])
        df_zero = df_zero.select(f.lit('pct_0').alias('summary'),
                                 *[(f.col(col) / f.lit(n_rows_total)).alias(col) for col in num_cols])    

        df_mean = df.select(f.lit('mean').alias('summary'),
                         *[f.avg(col).alias(col) for col in num_cols])

        df_min = df.select(f.lit('min').alias('summary'),
                        *[f.min(col).alias(col) for col in num_cols])

        df_p1 = df.select(f.lit('p_1').alias('summary'),
                         *[f.expr(f'percentile_approx({col}, 0.01)').alias(col) for col in num_cols])

        df_p25 = df.select(f.lit('p_25').alias('summary'),
                        *[f.expr(f'percentile_approx({col}, 0.25)').alias(col) for col in num_cols])

        df_p50 = df.select(f.lit('p_50').alias('summary'),
                        *[f.expr(f'percentile_approx({col}, 0.50)').alias(col) for col in num_cols])

        df_p75 = df.select(f.lit('p_75').alias('summary'),
                        *[f.expr(f'percentile_approx({col}, 0.75)').alias(col) for col in num_cols])

        df_p99 = df.select(f.lit('p_99').alias('summary'),
                        *[f.expr(f'percentile_approx({col}, 0.99)').alias(col) for col in num_cols])

        df_max = df.select(f.lit('max').alias('summary'),
                        *[f.max(col).alias(col) for col in num_cols])

        all_dfs = [df_n, df_miss, df_zero, df_mean, df_min, df_p1,
                   df_p25, df_p50, df_p75, df_p99, df_max]
        df_summary = reduce(lambda x, y: x.unionByName(y), all_dfs)

        df_tmp = df.select(*(f.col(col).cast('string').alias(col) for col in num_cols))
        df_tmp = df_tmp.na.fill(value='Nulo')   

        df_mode = _get_mode(df_tmp)
        pd_mode = df_mode.toPandas()

        pd_summary = df_summary.toPandas()    
        pd_summary = pd_summary.set_index('summary').T
        pd_summary.reset_index(inplace=True)
        pd_summary = pd_summary.rename_axis(None, axis=1)
        pd_summary = pd_summary.rename(columns={'index': 'feature'})

        merged = pd_summary.merge(pd_mode, how='left', on=['feature'])

        data_date = date_eval[:4]+date_eval[5:7]
        merged['part_date'] = data_date

        reorder_cols = ['feature', 'part_date', 'n', 'pct_miss', 'pct_0', 'mean','mode',
                        'min', 'p_1', 'p_25', 'p_50', 'p_75', 'p_99', 'max']
        merged = merged[reorder_cols]

        return merged

    @staticmethod
    def audit_varcat(df, date_eval, not_eval: list = []):
        '''
        Get % that the most frequent level represents
        in the whole variable
        
        :param df: Dataframe to analyze
        :type df: pyspark.sql.DataFrame
        :param date_eval: Date in the format '%Y-%m-%d'
        :type date_eval: str
        :param not_eval: List of columns not to include
            in the analysis
        :type not_eval: list
        :return: Dataframe with summary statistics
        :rtype: pandas.DataFrame
        '''
        from pyspark.sql import Window
        import pyspark.sql.functions as f
        import pyspark.sql.types as t

        cat_cols = [field.name for field in df.schema.fields if isinstance(field.dataType, t.StringType)]
        cat_cols = [col for col in cat_cols if col not in not_eval]

        df = df.select(*cat_cols)
        df = df.na.fill(value='Nulo')

        stack_string = ', '.join([f"\'{v}\', {v}" for v in df.columns])
        df_audit = df.select(f.expr(f'stack({len(df.columns)}, {stack_string}) as (variable, level)')) \
                     .groupBy('variable', 'level').count().orderBy('variable', 'level')

        n_rows_total = df.count()
        df_audit = df_audit.select(f.col('variable'), f.col('level'),
                                   f.col('count'), (f.col('count') / f.lit(n_rows_total)).alias('perc_total'))
        df_audit = df_audit.select(f.lit(date_eval).alias('date_part'), 'variable', 'level', 'count',
                                   'perc_total')

        return df_audit.toPandas()