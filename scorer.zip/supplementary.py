# ==================================================================================
# PACKAGES
# ==================================================================================
# Standard
import logging
import sys

# Third Party
from pyspark import StorageLevel
# ==================================================================================
# LOGGER
# ==================================================================================
logger = logging.getLogger(__name__)
# ==================================================================================
# LOCAL
# ==================================================================================
# ==================================================================================
# CLASSES
# ==================================================================================
class AuxHandleData:
    '''
    Wrapper with auxiliary tasks to
    main steps
    
    :param num_excpt_cols: Columns to not
        compute variance
    :type num_excpt_cols: list
    '''
    def __init__(self, num_excpt_cols=None):
        '''
        Constructor Method
        '''
        self._num_excpt_cols = num_excpt_cols
    
    @property
    def num_excpt_cols(self):
        return self._num_excpt_cols
        
    def __retr_by_step_decor(step=None):
        '''
        Do sequentials slices of dataframe to 
        process
        
         == TEMPORARY == 
        Only accepts functions that returns
        dictionaries

        :param step: number of columns to
            read at every step, should be set
            through config file, defaults to None
        :type step: int
        '''
        from functools import wraps
        
        def decorator(func):
            @wraps(func)
            def wrapper(self, step=step, *args, **kwargs):
                from itertools import tee
                from functools import reduce

                def _custom_range(start, end, step):
                    i = start
                    while i < end:
                        yield i
                        i += step
                    yield end

                def _pairwise(iterable):
                    a, b = tee(iterable)
                    next(b, None)
                    return zip(a, b)
                
                def _copy_dict(d, mods={}, **kwargs):
                    res = dict(d)
                    res.update(mods)
                    res.update(kwargs)
                    return res

                if kwargs.get('df') is None:
                    kwargs['df'] = self.data
                if step is None:
                    step = self.config['step_size']
                
                outputs = []
                for prev, curr in _pairwise(_custom_range(0, len(kwargs['df'].columns), step)):
                    df_tmp = kwargs['df'].select(kwargs['df'].columns[prev:curr])
                    _kwargs = _copy_dict(kwargs, mods={'df': df_tmp})

                    dict_parc = func(self, *args, **_kwargs)
                    outputs.append(dict_parc)

                dict_ret = reduce(lambda x, y: {**x, **y}, outputs)
                
                logger.debug(dict_ret)

                return dict_ret
            return wrapper
        return decorator
    
    def _get_num_cols(self, df=None):
        '''
        Returns a list containing all
        numerical variables
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        :return: Numerical columns
        :rtype: list
        '''
        import pyspark.sql.types as t
        
        if df is None:
            df = self.data
        
        num_vars = [field.name for field in df.schema.fields
                    if not isinstance(field.dataType, t.StringType)]
        
        return num_vars
    
    def _get_str_cols(self, df=None):
        '''
        Returns a list containing all
        string variables
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        :return: String columns
        :rtype: list
        '''
        import pyspark.sql.types as t
        
        if df is None:
            df = self.data
        
        cat_vars = [field.name for field in self.data.schema.fields
                    if isinstance(field.dataType, t.StringType)]
        
        return cat_vars
    
    @__retr_by_step_decor()
    def get_cnt_dist(self, df=None, rsd=None):
        '''
        Generate a dictionary with count distinct of values
        by columns in a dataframe
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        :param rsd: Maximum relative standard deviation
            allowed, defaults to None
        :type rsd: float, optional
        :return: Columns names with respective count distinct
        :rtype: dict
        '''
        import pyspark.sql.functions as f
        
        if rsd is None:
            rsd = self.config['rsd']

        agg_row = df.agg(*[f.approx_count_distinct(f.col(c), rsd).alias(c) for c in df.columns]).collect()
        agg_dict = [row.asDict() for row in agg_row][0]
        
        return agg_dict
    
    @__retr_by_step_decor()
    def get_perc_null(self, df=None):
        '''
        Calculate % of nulls by columns
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        :return: Columns names with respective % of nulls in it
        :rtype: dict
        '''
        import pyspark.sql.functions as f

        agg_row = df.select(*[((f.sum(f.col(c).isNull().cast('double'))) \
                               / (f.count('*'))).alias(c) for c in df.columns]).collect()
        agg_dict = [row.asDict() for row in agg_row][0]

        return agg_dict

    @__retr_by_step_decor()
    def get_variance(self, df=None, excpt_vars=None, pop=None):
        '''
        Calculates variance for numerical variables

        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        :param excpt_vars: List of columns to not analyze
        :type excpt_vars: str
        :param pop: If the data represents the entire
            population `True`, to sample `False`,
            defaults to False
        :type pop: boolean
        :return: Numerical columns names with respective 
            variance of nulls in it
        :rtype: dict
        '''
        import pyspark.sql.functions as f       
        
        if excpt_vars is None:
            excpt_vars = list(self.config['spine'].values())
        self._num_excpt_cols = excpt_vars
        if pop is None:
            pop = self.config['population']

        num_vars = self._get_num_cols(df)
        num_vars = [col for col in num_vars if col not in excpt_vars]
        
        df_num = df.select(*num_vars)

        if pop:
            agg_expr = [f.var_pop(col).alias(col) for col in df_num.columns]
        else:
            agg_expr = [f.var_samp(col).alias(col) for col in df_num.columns]

        agg_row = df_num.select(*agg_expr).collect()
        agg_dict = [row.asDict() for row in agg_row][0]

        return agg_dict
    
    def _get_mode(self, df):
        '''
        Get % that the most frequent level represents
        in the whole variable
        
        :param df: Dataframe to analyze
        :type df: pyspark.sql.DataFrame
        '''
        from pyspark.sql import Window
        import pyspark.sql.functions as f
        import pyspark.sql.types as t

        stack_string = ', '.join([f"\'{v}\', {v}" for v in df.columns])
        df_mode = df.select(f.expr(f'stack({len(df.columns)}, {stack_string}) as (COLUMN, LEVEL)')) \
                    .groupBy('COLUMN', 'LEVEL').count()

        count_rows = df.count()
        win = Window().partitionBy('COLUMN').orderBy(f.col('count').desc())
        df_mode = df_mode.withColumn('row_num', f.row_number().over(win)) \
                                .where(f.col('row_num') == 1) \
                                .drop('row_num') \
                                .withColumn('perc_mode', f.col('count') / f.lit(count_rows)) \
                                .select(f.col('COLUMN'), f.col('perc_mode'))

        return df_mode
    
    @__retr_by_step_decor()
    def get_mode_perc(self, df=None, except_list=None):
        '''
        Get % that the most the mode represents
        in the whole variable

        :param df: Dataframe to analyze
        :type df: spark.sql.DataFrame
        :param except_list: List of variables names to 
            not analyze, defaults to empty list
        :type except_list: list
        :return: Key value, where key is the column name
            and value is the mode %
        :rtype: dict 
        '''
        from pyspark.sql import DataFrame
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        if except_list is None:
            except_list = list(self.config['spine'].values())      
        
        # Stack only accepts variables of the same type
        str_cols = [field.name for field in df.schema.fields \
                    if isinstance(field.dataType, t.StringType)]
        str_cols = [col for col in str_cols if col not in except_list]
        num_cols = [col for col in df.columns if col not in str_cols+except_list]

        if len(str_cols) > 0:
            df_tmp = df.select(*str_cols)

            df_mode_str = self._get_mode(df_tmp)
        else:
            df_mode_str = None

        if len(num_cols) > 0:
            df_tmp = df.select(*num_cols)
            df_tmp = df_tmp.select(*(f.col(col).cast('float').alias(col) for col in df_tmp.columns))

            df_mode_num = self._get_mode(df_tmp)
        else:
            df_mode_num = None

        if (df_mode_str is not None and isinstance(df_mode_str, DataFrame)) & \
           (df_mode_num is not None and isinstance(df_mode_num, DataFrame)):

            df_mode = df_mode_str.unionByName(df_mode_num)
        elif (df_mode_str is not None and isinstance(df_mode_str, DataFrame)) & \
                                                            (df_mode_num is None):
            df_mode = df_mode_str
            del df_mode_str
        elif (df_mode_num is not None and isinstance(df_mode_num, DataFrame)) & \
                                                            (df_mode_str is None):
            df_mode = df_mode_num
            del df_mode_num

        agg_row = df_mode.collect()
        agg_dict = [row.asDict() for row in agg_row]
        agg_dict = {var_dict['COLUMN']: var_dict['perc_mode'] for var_dict in agg_dict}

        return agg_dict
    
    def idntf_bin_vars(self, df=None, cnt_dist=None, expr_searc=['ind', 'flag', 'existe']):
        '''
        Get column names of binary columns
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        :param cnt_dist: Distinct count of values by columns
            defaults to None
        :type cnt_dist: dict
        
        
        :return: List of binary columns "1"/"0" and a list
            of encoded columns "S"/"N"
        :rtype: list
        '''
        import pyspark.sql.functions as f

        if df is None:
            df = self.data
        if cnt_dist is None:
            cnt_dist = self._cnt_dist
        
        # Posible Binary columns
        named_cols = []
        for str_expr in expr_searc:
            found_vars = list(filter(lambda i: str_expr in i, df.columns))
            named_cols = named_cols+found_vars
        pos_bin = [k for k in cnt_dist if cnt_dist[k] == 2]
        
        pos_bin = [col for col in pos_bin if col in named_cols]
        df = df.select(*pos_bin)

        dist_vals = df.select(*[f.collect_set(c).alias(c) for c in df.columns]).take(1)[0]

        bin_cols = [c for c in df.columns if
                          (set(dist_vals[c]).issubset({'1', '0'}) or set(dist_vals[c]).issubset({1, 0}))]
        
        bin_cols_enc = [c for c in df.columns if
                          (set(dist_vals[c]).issubset({'S', 'N'}) or set(dist_vals[c]).issubset({'s', 'n'}))]

        logger.debug(f'Binary variables: {bin_cols}')
        logger.debug(f'Already encoded binary variables: {bin_cols_enc}')
        
        return bin_cols, bin_cols_enc
    
    def repart(self, df=None, n_part=None):
        '''
        Set a new number of data partitions
        
        :param df: Dataframe to repartition
        :type df: pyspark.sql.DataFrame
        :param n_part: New number of partitions
        :type n_part: int, optional
        :return: When a df is given, returns a repartitioned
            dataframe
        :rtype: pyspark.sql.DataFrame
        '''
        if n_part is None:
            n_part = self.config['n_part']
            
        if df is None:
            self.data = self.data.repartition(n_part)
        else:
            df_repart = df.repartition(n_part)
            
            return df_repart
        
    def check_isnot_empty(self, df=None):
        '''
        Checks if a dataframe is empty or not
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        '''
        if df is None:
            df = self.data
        
        return bool(df.head(1))


class PersistManager:
    '''
    Load and Save objects    
    '''
    
    @staticmethod
    def red_n_part(df, n_part=1):
        '''
        Set new number of partitions
        
        :param df: Dataframe to reduce number of partitions
        :type df: pyspark.sql.DataFrame
        :param n_part: New number of partitions, defaults to 1
        :type n_part: int, optional
        :return: Repartitioned dataframe
        :rtype: pyspark.sql.DataFrame
        '''

        return df.coalesce(n_part)
    
    @staticmethod
    def save_df_into_lake(spark, *args, **kwargs):
        '''
        Save a dataframe as table in the lake
        
        :param spark: Valid Spark session
        :type spark: spark.sql.SparkSession
        '''
        
        pass
        
    
    @staticmethod
    def save_spark_obj(obj, path):
        '''
        Load a pyspark object from a given path
        
        :param obj: Pyspark object to save
        :type onj: Pyspark
        :param path: Filepath in local or HDFS to save 
        :type path: str
        '''
        return obj.write().overwrite().save(path)
    
    @staticmethod
    def load_spark_obj(obj, path):
        '''
        Load a pyspark object from a given path
        
        :param obj: Pyspark object to load
        :type onj: Pyspark
        :param path: Filepath in local or HDFS to read 
        :type path: str
        :return: Loaded Pyspark object
        :rtype: object
        '''
        return obj.load(path)

    @classmethod
    def save_as_csv_into_hdfs(cls, df, path):
        '''
        Saves a csv file in a hdfs folder
        
        :param df: Dataframe to convert to csv
        :type df: pyspark.sql.DataFrame
        :param path: Filepath in HDFS to save
        :type path: str
        '''
        df = cls.red_n_part(df, n_part=1)
        df.write \
          .mode('overwrite') \
          .options(header='True', delimiter=';') \
          .csv(path)
    
    @staticmethod
    def read_csv_from_hdfs(spark, path):
        '''
        Read a csv from a HDFS folder
        
        :param spark: Valid Spark session
        :type spark: spark.sql.SparkSession
        :param path: Path to a csv
        :type path: str
        :return: Loaded Dataframe 
        :rtype: pyspark.sql.DataFrame
        '''
        df = spark.read.csv(path, sep=';', inferSchema=True, header=True)

        return df
    
    @staticmethod
    def save_as_json(spark, sc, file, path):
        '''
        Save a dict as json in a HDFS folder
        
        :param spark: Valid Spark session
        :type spark: spark.sql.SparkSession
        :param sc: Valid Spark Context
        :type sc: pyspark.SparkContext
        :param file: File to save
        :type file: dict
        :param path: Path indicating where to save
        :type path: str
        '''
        spark.read.json(sc.parallelize([file])) \
             .coalesce(1).write.mode('overwrite').json(path)
     
    @staticmethod
    def load_json_from_hdfs(sc, path):
        '''
        load and Parse a Json from a HDFS directory
        
        :param sc: Valid Spark Context
        :type sc: pyspark.SparkContext
        :param path: Path indicating where to save
        :type path: str
        '''
        import ast
        
        file = sc.textFile(path).collect()
        file = ast.literal_eval(file[0])
        
        return file
    
    @staticmethod
    def append_partition(spark, *args, **kwargs):
        '''
        Append new partition to a already existing table in the lake
        
        :param spark: Valid Spark session
        :type spark: spark.sql.SparkSession
        '''
        
        pass
    
    @staticmethod
    def copy_from_local_to_hdfs(filename, folder_hdfs):
        '''
        Copy local file to a folder in HDFS
        
        :param filename: File name to copy
        :type filename: str
        :param folder_hdfs: Destination folder in HDFS
        :type folder_hdfs: str
        '''
        import os
        import subprocess
        
        user = os.environ['USER']
        
        path_local = os.path.join(os.getcwd(), filename)
        path_hdfs = os.path.join('/user', os.environ['USER'], folder_hdfs, filename)
        
        subprocess.call(['hdfs', 'dfs', '-put', '-f', path_local, path_hdfs])
        
        return 'Copy OK!'


class DateAux:
    '''
    Collections of functions related to dates
    '''
    @staticmethod
    def get_first_day_month(ref_date: str = None, rfd_format: str = None,
                            m_offset: int = 0, d_format: str = '%Y-%m-%d') -> str:
        """
        Get a string representing first day of a month from a given date,
        formated as chose.

        :param ref_date: Date reference to use, defaults to None, if so,
            uses current day
        :type ref_date: str, optional
        :param rfd_format: Date format of ref_date parameter, defaults to None
        :type rfd_format: str, optional unless ref_date is passed
        :param m_offset: Number of months to offset, negative values means
            offset to previous months, defaults to 0
        :type m_offset: int, optional
        :param d_format: Date format of returned date, defaults to '%Y-%m-%d'
        :type d_format: str
        :return: String representing the first day of month formated 
        :rtype: str
        """
        import datetime as dt
        from dateutil.relativedelta import relativedelta

        if ref_date:
            date = (dt.datetime.strptime(ref_date, rfd_format) + relativedelta(months=m_offset)) \
                                                                .replace(day=1).strftime(d_format)
        else:
            date = (dt.datetime.today() + relativedelta(months=m_offset)).replace(day=1).strftime(d_format)

        return date

    @staticmethod
    def get_last_day_month(ref_date: str = None, rfd_format: str = None,
                       m_offset: int = 0, d_format: str = '%Y-%m-%d') -> str:
        """
        Get a string representing last day of a month from a given date,
        formated as chose.

        :param ref_date: Date reference to use, defaults to None, if so,
            uses current day
        :type ref_date: str, optional
        :param rfd_format: Date format of ref_date parameter, defaults to None
        :type rfd_format: str, optional unless ref_date is passed
        :param m_offset: Number of months to offset, negative values means
            offset to previous months, defaults to 0
        :type m_offset: int, optional
        :param d_format: Date format of returned string date, defaults to '%Y-%m-%d'
        :type d_format: str
        :return: String representing the first day of month formated 
        :rtype: str
        """
        import datetime as dt
        from dateutil.relativedelta import relativedelta

        if ref_date:
            date = dt.datetime.strptime(ref_date, rfd_format)
        else:
            date = dt.datetime.today()

        end_date = ((dt.date(date.year + date.month // 12,
                        date.month % 12 + 1, 1) \
                        + relativedelta(months=m_offset)
                        - dt.timedelta(1))).strftime(d_format)

        return end_date
    
    @staticmethod
    def time_elapsed(t1: float, t0: float) -> float:
        '''
        Calculates difference between two time marks.
        
        :param t1: End time as a floating point 
            number expressed in seconds
        :type t1: float
        :param t0: Start time as a floating point 
            number expressed in seconds
        :type t0: float
        :return: Time elapsed as a floating point
            number expressed in hours
        :rtype: float
        '''
        import numpy as np
        
        return np.round((t1 - t0)/3600, 2)


class AuxML(AuxHandleData):
    '''
    Side functions to help with preprocess
    data
    '''
    def __init__(self, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
    
#     def _persist_df(self, df=None, storglvl=StorageLevel.MEMORY_AND_DISK):
#         '''
#         Sets the storage level to persist the contents of the DataFrame
        
#         :param df: Dataframe to persist
#         :type df: pyspark.sql.DataFrame
#         :param storglvl: Flags for controlling where the storage
#             will happens
#         :type storglvl: pyspark.StorageLevel
#         '''        
#         # Count action to immediately persists
#         if df is None:
#             self.data.persist(storglvl).count()
#         else:
#             df.persist(storglvl).count()
            
#             return df

    def create_id_col(self, df=None, id_name=None):
        '''
        Create monotonically increasing and unique ID,
        but not consecutive
        
        :param df: Dataframe to handle
        :type df: pyspark.sql.DataFrame
        :param id_name: Name of new id column
        :type id_name: str
        '''
        import pyspark.sql.functions as f
        
        if df is None:
            df = self.data
        if id_name is None:
            id_name = self.config['spine']['artf_id_col']
            
        self.data = df.withColumn(id_name, f.monotonically_increasing_id())
        self.data.persist().count()
        #self._persist_df()
        
    def create_ts_col(self, df=None, ts_name='exec_time'):
        '''
        Create TimeStamp Column
        
        :param df: Dataframe to handle
        :type df: pyspark.sql.DataFrame
        :param id_name: Name of new timestamp column
        :type id_name: str
        '''
        import pyspark.sql.functions as f
        
        if df is None:
            df = self.data
        
        self.data = df.withColumn(ts_name, f.current_timestamp())
        
        
    def merge_train_test_val(self):
        '''
        Merge each dataset into one
        
        :returns: Unique dataframe containing
            train, test, validation
        :rtype: pyspark.sql.DataFrame
        '''
        from functools import reduce
        
        dfs = [self._train, self._test, self._val]
        df = reduce(lambda x, y: x.unionByName(y), dfs)
        
        return df
        
    def resample_data(self, perc=0.5, split='pred'):
        '''
        Resamples data keeping x % of zeros 
        and all target observations
        
        :param perc: Percentage of 0's to keep
        :type perc: float
        :param split: Indicator to which dataset apply 
            the resampling, defaults to 'pred' (all data)
        :type split: str
        '''
        import pyspark.sql.functions as f
        
        dictionary = {0: perc, 1: 1}
        
        if split == 'train':
            self._train = self._train.sampleBy(self.config['spine']['target_col'], fractions=dictionary, seed=2012)
        elif split == 'test':
            self._test = self._test.sampleBy(self.config['spine']['target_col'], fractions=dictionary, seed=2012)
        elif split == 'val':
            self._val = self._val.sampleBy(self.config['spine']['target_col'], fractions=dictionary, seed=2012)
        else:
            self.data = self.data.sampleBy(self.config['spine']['target_col'], fractions=dictionary, seed=2012)


class ReportManager(PersistManager):
    '''
    Manage report builders
    '''    
    @staticmethod
    def gen_prior_report(prior_org, prior_use):
        '''
        Create prior report used in sample function
        
        :returns: Report of original and used prior
        :rtype: pandas.DataFrame
        '''
        import pandas as pd
        
        def __build_pd(dictry, prior_col):
            '''
            Create a pandas dataframe from prior dict
            
            :param dictry: Data source
            :type df: dict
            :param prior_col: Name of column
            :type prior_col: str
            
            '''
            pd_dictry = pd.DataFrame([dictry], index=[prior_col]).T.reset_index() \
                                                .rename(columns={'index': 'date'}) \
                                                .sort_values(by=['date'])

            return pd_dictry
            
        pd_org = __build_pd(prior_org, 'prior_original')
        pd_use = __build_pd(prior_use, 'prior_used')
        pd_prior = pd.merge(pd_org, pd_use, on='date', how='left')
        
        return pd_prior
    
    @staticmethod
    def merge_reports(reports, on):
        '''
        Merge Pandas Dataframes
        
        :param reports: List of dataframes to Merge
        :type reports: list(pandas.DataFrame)
        :param on: Colmuns to use as key to join
        :type on: list(str)
        :returns: Merged dataframe
        :rtype: pandas.DataFrame
        '''
        import pandas as pd
        from functools import reduce
        
        pd_merged = reduce(lambda x, y: x.merge(y, how='inner', on=on), reports)
        
        return pd_merged
    
    @staticmethod
    def get_feat_import(model, feat_names=None):
        '''
        Returns dataframe containing feature importances from
        a given model, class need to be imported outside

        :param model: Fitted Model
        :type model: "pyspark.ml.Model"
        :param feat_names: List with columns names used to create
            assembler, order is relevant
        :type feat_names: list
        :return: Dataframe with features importances
        :rtype: pandas.DataFrame
        '''
        import pandas as pd
        
        # Feat importance
        importances = model.featureImportances.toArray()
        feat_import_sorted = sorted(range(len(importances)), key=lambda k: importances[k], reverse=True)
        # Create a dataframe
        variables_name = [feat_names[i] for i in feat_import_sorted]
        variables_value = [importances[i] for i in feat_import_sorted]
        pd_feat_import = pd.DataFrame(list(zip(variables_name, variables_value)),
                                   columns=['feature', 'importance'])

        return pd_feat_import
    
    @staticmethod
    def get_original_feat_names(sc, path):
        '''
        Retrieve original feature names
        
        :param sc: Valid Spark Context
        :type sc: pyspark.SparkContext
        :param path: Path to final dict directory
        :type path: str
        :return: Original feature names
        :rtype: list
        '''
        features = PersistManager.load_json_from_hdfs(sc, path)
        features = [feat.split('_D_')[0] for feat in features['chosen_feat']]
        features = list(set(features))
        
        return features
        

class LakeAux:
    '''
    Manage auxiliary functions involving
    the lake and hdfs
    '''
    
    @staticmethod
    def get_most_recent_table(spark, schema, table):
        '''
        Get lastest version of a table saved in the lake
        
        :param spark: Valid Spark session
        :type spark: spark.sql.SparkSession
        :param schema: Database to look into
        :type schema: str
        :param table: Table to retrieve lastest version
        :type table: str
        '''
        tables = spark.sql(f'show tables in {schema}')

        tables = tables.select('tableName') \
                       .filter(f'tableName like "{table}_%"') \
                       .orderBy('tableName').collect()
        tb = max([t[0] for t in tables])
        
        return tb
    

class Merger(AuxHandleData, LakeAux):
    '''
    Merges intermediary tables
    
    :param spark: Valid Spark session
    :type spark: spark.sql.SparkSession
    :param config: Settings of ML operations
    :type config: dict
    :param schema: Database to read table from
    :type schema: str
    :param master_src: Table with potentials
    :type master_src: str
    :param data_src: Cleaned tables
    :type data_src: list(str)
    '''
    def __init__(self, spark, config, schema, master_src, data_src, *args, **kwargs):
        '''
        Constructor method
        '''
        self.spark = spark
        self.config = config
        self.schema = schema
        self.master_src = master_src
        self.data_src = data_src
        self.data = None
        super().__init__(*args, **kwargs)
        
    def merge_tables(self):
        '''
        Main function to merge all cleaned source
        tables in just one
        '''
        from functools import reduce
        
        master_latest = self.get_most_recent_table(self.spark, self.schema, self.master_src)
        logger.info(f'Latest Master: {master_latest}')
        df = self.spark.read.table(f'{self.schema}.{master_latest}')
        dfs = [df]
        
        droplist = [v for k, v in self.config['spine'].items() if not k.startswith('artf')]
        data_src_latest = []
        for table in self.data_src:
            tb_lastest = self.get_most_recent_table(self.spark, self.schema, table)
            tb_lastest = f'{self.schema}.{tb_lastest}'
            logger.info(f'Clean Source: {tb_lastest}')
            data_src_latest.append(tb_lastest)

            df_tmp = self.spark.read.table(tb_lastest)
            df_tmp = df_tmp.drop(*droplist)
            dfs.append(df_tmp)
   
        self.data = reduce(lambda x, y: x.join(y, [self.config['spine']['artf_id_col']], how='inner'), dfs)
        self.repart()
        
        return self.data, data_src_latest
    
    __call__ = merge_tables
    

class Criterion:
    '''
    Criteria for feature selection
    
    :param report: Report containing features and
        respective statistic value
    :type report: pandas.DataFrame
    '''
    def __init__(self, report):
        '''
        Constructor method
        '''
        self.report = report
        
    def top_criteron(self, top=30, feat_col='feature', imp_col='importance'):
        '''
        Keep the best X variables 
        
        :param top: Best x variables to use, defaults to 30
        :type top: int
        :param feat_col: Column containing features names
        :type feat_col: str
        :param imp_col: Column containing respective performance
        :type imp_col: str
        :return: Selected features
        :rtype: list
        '''
        import pandas as pd
        
        pd_top = self.report.sort_values(by=[imp_col], ascending=False)
        pd_top = pd_top[:top]
        top_feat = list(pd_top[feat_col])
        
        return top_feat
    
    def percentile_criterion(self, percentile=0.8, feat_col='feature', imp_col='importance'):
        '''
        For feature importances that sums up to one,
        selects variables that represents x percent of
        the total information gain
        
        :param percentile: Percentile of info gain to use
        :type percentile: float
        :param feat_col: Column containing features names
        :type feat_col: str
        :param imp_col: Column containing respective performance
        :type imp_col: str
        :return: Selected features
        :rtype: list
        '''
        import pandas as pd
        
        pd_perc = self.report.sort_values(by=[imp_col], ascending=False)
        pd_perc['cumsum_import'] = pd_perc[imp_col].cumsum()
        pd_perc = pd_perc[pd_perc['cumsum_import'] <= percentile]
        top_feat = list(pd_perc[feat_col])
        
        return top_feat
    
    def threshold_criterion(self, threshold=0.3, feat_col='feature', imp_col='importance'):
        '''
        Choose all variables above the threshold
        
        :param threshold: Value to cutout variables
        :type threshold: float
        :param feat_col: Column containing features names
        :type feat_col: str
        :param imp_col: Column containing respective performance
        :type imp_col: str
        :return: Selected features
        :rtype: list
        '''
        import pandas as pd
        
        pd_feat = self.report.sort_values(by=[imp_col], ascending=False)
        pd_feat = pd_feat[pd_feat[feat_col] > threshold]
        top_feat = list(pd_perc[feat_col])
        
        return top_feat
    
    def perc_criterion(self, perc=0.1, feat_col='feature', imp_col='importance'):
        '''
        Choose the best x percent of all variables
        
        :param perc: Percentage of features to keep
        :type perc: float
        :param feat_col: Column containing features names
        :type feat_col: str
        :param imp_col: Column containing respective performance
        :type imp_col: str
        :return: Selected features
        :rtype: list
        '''
        import pandas as pd
        
        n_vars = int(self.report.shape[0] * perc)
        pd_top = self.report.sort_values(by=[imp_col], ascending=False)
        pd_top = pd_top[:n_vars]
        top_feat = list(pd_top[feat_col])
        
        return top_feat
    

class MergerRaw(AuxHandleData, LakeAux):
    '''
    Merges raw tables
    
    :param spark: Valid Spark session
    :type spark: spark.sql.SparkSession
    :param config: Settings of ML operations
    :type config: dict
    :param schema: Database to read table from
    :type schema: str
    :param master_src: Table with potentials
    :type master_src: str
    :param data_src: Source tables
    :type data_src: list(str)
    :param mode: Filter potentials, if "DEV"
        use only train
    :type mode: str
    :param codpers_org: Original name of
        identification column
    :type codpers_org: str
    :param date_col_org: Original name of
        date column
    :type date_col_org: str
    :param ini_date: Initial date to look,
        in the format %Y-%m-%d
    :type ini_date: str
    :param end_date: End date to look,
        in the format %Y-%m-%d
    :type end_date: str
    '''
    def __init__(self, spark, config, schema, master_src, data_src, mode,
                 codpers_org, date_col_org, ini_date, end_date,
                 *args, **kwargs):
        '''
        Constructor method
        '''
        self.spark = spark
        self.config = config
        self.schema = schema
        self.master_src = master_src
        self.data_src = data_src
        self.mode = mode
        self.codpers_org = codpers_org
        self.date_col_org = date_col_org
        self.ini_date = ini_date
        self.end_date = end_date
        self.data = None
        super().__init__(*args, **kwargs)
        
    def merge_tables(self):
        '''
        Main function to merge all source
        tables in just one
        
        :return: Dataframe merged
        :rtype: spark.sql.DataFrame
        '''
        import pyspark.sql.functions as f
        from functools import reduce
        
        master_latest = self.get_most_recent_table(self.spark, self.schema, self.master_src)
        logger.info(f'Latest Master: {master_latest}')
        df = self.spark.read.table(f'{self.schema}.{master_latest}')
        if self.mode == 'DEV':
            df = df.filter(f.col(self.config['spine']['ind_split_col']) == 'train')
        dfs = [df]
        for table in self.data_src:
            logger.info(f'Data Source: {table}')
            tb_src = self.spark.read.table(f'{table}')          
            tb_src = tb_src.withColumnRenamed(self.codpers_org, self.config['spine']['ident_col']) \
                           .withColumnRenamed(self.date_col_org, self.config['spine']['date_col'])
            tb_src = tb_src.filter(f.col(self.config['spine']['date_col']) \
                                   .between(self.ini_date, self.end_date))
            dfs.append(tb_src)
   
        self.data = reduce(lambda x, y: x.join(y,
                                               [self.config['spine']['ident_col'],
                                                self.config['spine']['date_col']],
                                               how='inner'), dfs)
        self.repart()
        
        return self.data
    
    __call__ = merge_tables
    

class MergerDF(AuxHandleData, LakeAux):
    '''
    Merges raw tables
    
    :param spark: Valid Spark session
    :type spark: spark.sql.SparkSession
    :param config: Settings of ML operations
    :type config: dict
    :param schema: Database to read table from
    :type schema: str
    :param base_src: Dataframe base
    :type base_src: pyspark.sql.DataFrame
    :param data_src: Source tables
    :type data_src: list(str)
    :param mode: Filter potentials, if "DEV"
        use only train
    :type mode: str
    :param codpers_org: Original name of
        identification column
    :type codpers_org: str
    :param date_col_org: Original name of
        date column
    :type date_col_org: str
    :param ini_date: Initial date to look,
        in the format %Y-%m-%d
    :type ini_date: str
    :param end_date: End date to look,
        in the format %Y-%m-%d
    :type end_date: str
    '''
    def __init__(self, spark, config, schema, base_src, data_src,
                 codpers_org, date_col_org, ini_date, end_date,
                 *args, **kwargs):
        '''
        Constructor method
        '''
        self.spark = spark
        self.config = config
        self.schema = schema
        self.base_src = base_src
        self.data_src = data_src
        self.codpers_org = codpers_org
        self.date_col_org = date_col_org
        self.ini_date = ini_date
        self.end_date = end_date
        self.data = None
        super().__init__(*args, **kwargs)
        
    def merge_tables(self):
        '''
        Main function to merge all source
        tables in just one
        
        :return: Dataframe merged
        :rtype: spark.sql.DataFrame
        '''
        import pyspark.sql.functions as f
        from functools import reduce
        
        dfs = [self.base_src]
        for table in self.data_src:
            logger.info(f'Data Source: {table}')
            tb_src = self.spark.read.table(f'{table}')     
            tb_src = tb_src.withColumnRenamed(self.codpers_org, self.config['spine']['ident_col']) \
                           .withColumnRenamed(self.date_col_org, self.config['spine']['date_col'])
            tb_src = tb_src.filter(f.col(self.config['spine']['date_col']) \
                                   .between(self.ini_date, self.end_date))
            dfs.append(tb_src)
   
        self.data = reduce(lambda x, y: x.join(y,
                                               [self.config['spine']['ident_col'],
                                                self.config['spine']['date_col']],
                                               how='inner'), dfs)
        self.repart()
        
        return self.data
    
    __call__ = merge_tables


class OpenPyXlManager:
    '''
    Represents a editor of reports with formated
    cells using the package openpyxl
    '''    
    
    @staticmethod
    def write_data(sheet, df):
        '''
        Write data into the excel sheet
        
        :param sheet: Sheet to append data
        :type sheet: openpyxl.worksheet.worksheet.Worksheet
        :param df: Dataframe to use
        :type df: pandas.DataFrame
        '''
        from openpyxl.utils.dataframe import dataframe_to_rows
        for r in dataframe_to_rows(df, index=False, header=True):
            if r != [None]:
                sheet.append(r)
                
    @staticmethod
    def format_cols(sheet, columns, style, font, font_a):
        '''
        Change Style and font in the given sheet
        
        :param sheet: Sheet to change style
        :type sheet: openpyxl.worksheet.worksheet.Worksheet
        :param columns: List of columns to apply
        :type columns: list(str)
        :param style: Openpyxl style name
        :type style: str
        :param font: Font to be used
        :type font: openpyxl.styles.Font
        '''
        from openpyxl.styles import Font
        
        for col in columns:
            for cell in sheet[col] + sheet[1]:
                cell.style = style
                cell.font = font
                if col == 'A':
                    cell.font = font_a
    
    @staticmethod
    def perc_format_cols(sheet, columns):
        '''
        Apply percentage format to specified columns
        
        :param sheet: Sheet to change
        :type sheet: openpyxl.worksheet.worksheet.Worksheet
        :param columns: List of columns to apply
        :type columns: list(str)
        '''
        from openpyxl.styles import numbers
        
        for perc_col in columns:
            for cell in sheet[perc_col]:
                cell.number_format = numbers.FORMAT_PERCENTAGE_00
    
    @staticmethod
    def header_format(sheet, font, fill):
        '''
        Apply format to the header
        
        :param sheet: Sheet to change
        :type sheet: openpyxl.worksheet.worksheet.Worksheet
        :param font: Font to be used
        :type font: openpyxl.styles.Font
        :param fill: Color to fill
        :type fill: from openpyxl.styles.PatternFill        
        '''
        from openpyxl.styles import Font, PatternFill
        
        for cell in sheet['1:1']:
            cell.font = font
            cell.fill = fill

    @staticmethod
    def cond_format_text(sheet, df, columns, text_color):
        '''
        Fill cells based on conditional rules based on text

        :param sheet: Sheet to change
        :type sheet: openpyxl.worksheet.worksheet.Worksheet
        :param df: Dataframe to use as reference to qty of rows
        :type df: pandas.DataFrame
        :param columns: List of columns to apply
        :type columns: list(str)
        :param text_color: Text to match and openpyxl.styles.PatternFill
            instanced to fill in the cell
        :type text_color: dict
        '''
        from openpyxl.formatting.rule import Rule
        from openpyxl.styles import PatternFill
        from openpyxl.styles.differential import DifferentialStyle

        for col in columns:
            for text, color in text_color.items():
                sheet.conditional_formatting.add(f'{col}1:{col}{len(df)+1}',
                                                 Rule(type='expression', operator='containsText',
                                                      formula=[f'NOT(ISERROR(SEARCH("{text}", {col}1)))'],
                                                      stopIfTrue=True,
                                                      dxf = DifferentialStyle(fill=color)))