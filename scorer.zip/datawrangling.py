# ==================================================================================
# PACKAGES
# ==================================================================================
# Standard
import logging

# ==================================================================================
# LOGGER
# ==================================================================================
logger = logging.getLogger(__name__)
# ==================================================================================
# LOCAL
# ==================================================================================
import supplementary as supp
import mlfeatures as mlf
# ==================================================================================
# CLASSES
# ==================================================================================
class Cleaner(supp.AuxHandleData):
    '''
    Represents a wrapper to clean the data
    
    :param data: Data to manipulate
    :type data: pyspark.sql.DataFrame
    :param config: Settings of ML operations
    :type config: dict
    :param dcount: Count distinct of values by columns
        in data, defaults to None
    :type dcount: dict, optional
    :param pnull: Percentage of nulls by columns
        in data, defaults to None
    :type pnull: dict, optional
    :param bin_vars: Name of dummy columns 
        in data, defaults to None
    :type bin_vars: list, optional
    :param bin_enc: Name of encoded binary columns 
        in data, e.g "S"/"N", defaults to None
    :type bin_enc: list, optional
    :param varc: Variance by numericals columns
        in data, defaults to None
    :type varc: dict, optional
    '''
    
    def __init__(self, data, config, dcount=None, pnull=None,
                 bin_vars=None, bin_enc=None, varc=None, pmode=None,
                 *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
        self.data = data
        self.config = config
        self._cnt_dist = dcount
        self._perc_null = pnull
        self._bin_vars = bin_vars
        self._bin_enc = bin_enc
        self._varc = varc
        self._pmode = pmode
        

    @property
    def cnt_dist(self):
        return self._cnt_dist
    
    @property
    def perc_null(self):
        return self._perc_null
    
    @property
    def bin_vars(self):
        return self._bin_vars
    
    @property
    def bin_enc(self):
        return self._bin_enc
    
    @property
    def varc(self):
        return self._varc
    
    @property
    def pmode(self):
        return self._pmode
    
    @cnt_dist.setter
    def cnt_dist(self, distc):
        if set(distc.keys()) == set(self.data.columns):
            try:
                self._cnt_dist = distc
            except (ValueError, IndexError):
                exit('Couldn\'t set attribute')
        else:
            raise ValueError('Columns of df and dict keys don\'t match')

    @perc_null.setter
    def perc_null(self, nullp):
        if set(nullp.keys()) == set(self.data.columns):
            try:
                self._perc_null = nullp
            except (ValueError, IndexError):
                exit('Couldn\'t set attribute')
        else:
            raise ValueError('Columns of df and dict keys don\'t match')

    @bin_vars.setter
    def bin_vars(self, bin_list):
        if isinstance(bin_list, list):
            try:
                self._bin_vars = bin_list
            except (TypeError):
                exit('Couldn\'t set attribute')
        else:
            raise TypeError('Must be a list')
            
    @bin_enc.setter
    def bin_enc(self, bin_list):
        if isinstance(bin_list, list):
            try:
                self._bin_enc = bin_list
            except (TypeError):
                exit('Couldn\'t set attribute')
        else:
            raise TypeError('Must be a list')
        
    @varc.setter
    def varc(self, dvarc):
        num_vars = self._get_num_cols()
        num_vars = [col for col in num_vars if col not in self._num_excpt_cols]
        if set(dvarc.keys()) == set(num_vars):
            try:
                self._varc = dvarc
            except (ValueError, IndexError):
                exit('Couldn\'t set attribute')
        else:
            raise ValueError('Numerical columns of df and dict keys don\'t match')
    
    @pmode.setter
    def pmode(self, pmode_dict):
        df_columns = [col for col in self.data.columns if col not in list(self.config['spine'].values())]
        if set(pmode_dict.keys()) == set(df_columns):
            try:
                self._pmode = pmode_dict
            except (ValueError, IndexError):
                exit('Couldn\'t set attribute')
        else:
            raise ValueError('Columns of df and dict keys don\'t match')
    
    def rmv_whitespace(self):
        '''
        Trims and elimantes whitespaces among
        categorical columns
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        num_vars = self._get_num_cols()
        logger.debug(num_vars)
        
        self.data = self.data.select(*[f.col(col) for col in self.data.columns
                                       if col in num_vars],
                                     *[f.when(f.length(f.trim(f.col(field.name))) != 0,
                                              f.trim(f.col(field.name)).cast(field.dataType))
                                        .otherwise(None).alias(field.name) for field
                                        in self.data.schema.fields if isinstance(field.dataType,
                                                                                 t.StringType)])

    def enc_bin_vars(self):
        '''
        Encodes binary columns.
        Positive level: "S" will be "1" and
        negative level: "N" will be "0"
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        #Ensure bin cols are intenger
        self.data = self.data.select(*[f.col(col) for col in self.data.columns
                                       if col not in self._bin_vars],
                                     *[f.col(col).cast('integer').alias(col) for col in self.data.columns
                                       if col in self._bin_vars])

        # Encoding
        self.data = self.data.select(*[col for col in self.data.columns if col not in self._bin_enc],
                                     *[f.when(f.col(col) == 'S', 1).otherwise(0) \
                                       .alias(col) for col in self._bin_enc if col not in self.config['bin_input']],
                                     *[f.when(f.col(col) == 'S', '1').when(f.col(col) == 'N', '0') \
                                       .otherwise('sin_info').alias(col) for col in self._bin_enc
                                       if col in self.config['bin_input']])

    def drop_null(self):
        '''
        Delete columns with higher percentage 
        of nulls than given threshold        
        '''
        cols_drop = [k for k in self._perc_null if self._perc_null[k] > self.config['null_threshold']]
        logger.debug(cols_drop)
        
        self.data = self.data.drop(*cols_drop)

    def drop_constant(self, excpt_vars=None):
        '''
        Delete columns with constant values
        
        :param excpt_vars: List of columns not drop,
            defaults to None
        :type excpt_vars: str
        '''
        if excpt_vars is None:
            excpt_vars = list(self.config['spine'].values())
        
        cols_drop = [k for k in self._cnt_dist if self._cnt_dist[k] < 2 and k not in excpt_vars]
        logger.debug(cols_drop)
        
        self.data = self.data.drop(*cols_drop)

    def rmv_num_low_vars(self):
        '''
        Delete numerical columns with lower
        variances than given threshold        
        '''
        cols_drop = [k for k in self._varc if self._varc[k] < self.config['varc_threshold']]
        logger.debug(cols_drop)
        
        self.data = self.data.drop(*cols_drop)

    def to_upper(self):
        '''
        Convert all categorical variables
        to uppercase        
        '''
        import pyspark.sql.functions as f
        
        except_vars = self._get_num_cols() + list(self.config['spine'].values())
        
        self.data = self.data.select(*[f.col(col) for col in self.data.columns if col in except_vars],
                                     *[f.upper(f.col(col)).alias(col) for col in self.data.columns
                                       if col not in except_vars])

    def reg_replace(self, patrn, replc):
        '''
        Replace all substrings of the specified
        string value that match regexp with rep
        
        :param patrn: Pattern to search for
        :type patrn: str
        :param replc: Text to replace
        :type replc: str
        '''
        import pyspark.sql.functions as f
        
        except_vars = self._get_num_cols() + list(self.config['spine'].values())
        
        self.data = self.data.select(*[col for col in self.data.columns if col in except_vars],
                                     *[f.regexp_replace(f.col(col), patrn, replc).alias(col)
                                       for col in self.data.columns if col not in except_vars])
        
    def fill_null(self, value, subset):
        '''
        Replace null values
        
        :param value: Value to fill in 
        :type value: str
        :param subset: List of columns to do
            the imputation
        :type subset: str
        '''

        self.data = self.data.na.fill(value=value, subset=subset)
    
    def drop_mode_threshold(self, excpt_vars=None):
        '''
        Delete columns quasi constant values
        
        :param excpt_vars: List of columns not drop,
            defaults to None
        :type excpt_vars: str
        '''
        if excpt_vars is None:
            excpt_vars = list(self.config['spine'].values())
        
        cols_drop = [k for k in self._pmode if self._pmode[k] > self.config['varc_threshold'] and k not in excpt_vars]
        logger.debug(cols_drop)
        
        self.data = self.data.drop(*cols_drop)