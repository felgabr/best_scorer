# ==================================================================================
# PACKAGES
# ==================================================================================
# Standard
import getpass
import logging
import os
import signal
import sys
import time

# Third Party
from pyspark
# ==================================================================================
# LOGGER
# ==================================================================================
logger = logging.getLogger(__name__)
# ==================================================================================
def build_spark_session(name: str='', size:str='S', args:list=[], kinit:bool=False,
                        time_out:int=150, jars:list=[] , py_files:list=[] , path_prefix: str, 
                        test_mode=False) -> pyspark.sql.SparkSession:
    """
    Creates Spark Session
    """
    pass


def __define_tp_param_email(param):
    '''
    '''
    if type(param) is str:
        return [param]
    elif type(param) is list:
        return param
    else:
        return ['']

def send_email(sender='', to=(), message='', subject='', cc=(), cco=(), attch=None):
    """
    Send email
    """
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    FROM = sender
    TO = __define_tp_param_email(to)
    CC = __define_tp_param_email(cc)
    CCO = __define_tp_param_email(cco)
    msg = MIMEMultipart('alternative')
    msg['From'] = FROM
    msg['To'] = ', '.join(TO)
    msg['Subject'] = subject
    part = MIMEText(message, 'html')
    msg.attach(part)
    if type(attch) == list or type(attch) == tuple:
        tmp = {}
        for adj in attch:
            tmp[adj] = adj.split('/')[-1]
        attch = tmp

    if attch is not None:
        for route, name in attch.items():
            filename = route
            part = MIMEBase('application', "octet-stream")
            part.set_payload(open(filename, "rb").read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment; filename="' + name + '"')
            msg.attach(part)
    mail = smtplib.SMTP('email.domain')
    mail.ehlo()
    mail.starttls()
    toaddrs = TO + CC + CCO
    mail.sendmail(FROM, toaddrs, msg.as_string())
    mail.quit()