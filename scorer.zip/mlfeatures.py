# ==================================================================================
# PACKAGES
# ==================================================================================
# Standard
import logging

# Third Party
import pyspark
# ==================================================================================
# LOGGER
# ==================================================================================
# ==================================================================================
# LOCAL
# ==================================================================================
import supplementary as supp

# ==================================================================================
# FUNCTIONS
# ==================================================================================
def _wrapper_get_cramer(target_col):
    '''
    Wrapper to use attribute in a Pandas UDF
    
    :param target_col: Column name of target
    :type: str
    :returns: Pandas UDF to get cramer's V
    rtype: function
    '''
    import pyspark.sql.functions as f
    import pyspark.sql.types as t        

    target_col = target_col

    schema = t.StructType([t.StructField('feature', t.StringType(), True),
               t.StructField('cramer_v', t.FloatType(), True),
               t.StructField('pred_power', t.StringType(), True)])

    @f.pandas_udf(schema, f.PandasUDFType.GROUPED_MAP)
    def get_cramer(data):
        '''
        Pandas UDF to Get Cramer's V
        '''
        import scipy.stats as ss
        import numpy as np
        import pandas as pd
        import os
        os.environ['ARROW_PRE_0_15_IPC_FORMAT']='1'

        def cramers_corrected_stat(confusion_matrix):
            '''
            calculate Cramers V statistic for categorial-categorial 
            association. Uses correction from Bergsma and Wicher, 
            Journal of the Korean Statistical Society 42 (2013): 323-328
            '''
            chi2 = ss.chi2_contingency(confusion_matrix)[0]
            n = confusion_matrix.sum().sum()
            phi2 = chi2/n
            r, k = confusion_matrix.shape
            phi2corr = max(0, phi2 - ((k-1)*(r-1))/(n-1))    
            rcorr = r - ((r-1)**2)/(n-1)
            kcorr = k - ((k-1)**2)/(n-1)

            return np.sqrt(phi2corr / min((kcorr-1), (rcorr-1)+0.001))

        data = data.drop(['group'], axis=1)

        rows = []
        columns = list(data.columns)
        columns.remove(target_col)    
        for column in columns:
            confusion_matrix = pd.crosstab(data[column], data[target_col])
            cramers = cramers_corrected_stat(confusion_matrix) # Cramer's V test
            rows.append(np.round(cramers, 2)) # Keeping of the rounded value of the Cramer's V  

        df = pd.DataFrame({'feature': columns, 'cramer_v': rows})

        bins = [0, 0.1, 0.3, 0.6, np.inf]
        labels = ['very_weak', 'weak', 'medium', 'strong']
        df['pred_power'] = pd.cut(df.cramer_v, bins=bins, labels=labels, right=False)

        return df

    return get_cramer

def wrapper_get_mutual_info(target_col):
    '''
    Wrapper to use attribute in a Pandas UDF
    
    :param target_col: Column name of target
    :type: str
    :returns: Pandas UDF to get mutual information
    rtype: function
    '''
    import pyspark.sql.functions as f
    import pyspark.sql.types as t

    target_col = target_col

    schema = t.StructType([t.StructField('feature', t.StringType(), True),
                           t.StructField('mutual_information', t.FloatType(), True),
                           t.StructField('pred_power', t.StringType(), True)])


    @f.pandas_udf(schema, f.PandasUDFType.GROUPED_MAP)
    def get_mutual_info(data):
        '''
        Pandas UDF to Get Mutual info
        '''
        from sklearn.feature_selection import mutual_info_classif as mic
        from sklearn.feature_selection import SelectPercentile
        import numpy as np
        import pandas as pd
        import os
        os.environ['ARROW_PRE_0_15_IPC_FORMAT']='1'

        X_train = data.drop([target_col, 'group'], axis=1)
        X_new = SelectPercentile(mic, percentile=10).fit(X_train, data[target_col])

        mutual_info = pd.Series(X_new.scores_)
        mutual_info.index = X_train.columns
        mutual_info.sort_values(ascending=False, inplace=True)
        df_mi = pd.DataFrame(mutual_info, columns=['mutual_information'])

        df_mi = df_mi.reset_index()
        df_mi.rename(columns={'index': 'feature'}, inplace=True)

        bins = [0, 0.02, 0.1, 0.3, 0.5, np.inf]
        labels = ['not_useful', 'weak', 'medium', 'strong', 'suspicious']
        df_mi['pred_power'] = pd.cut(df_mi.mutual_information, bins=bins, labels=labels, right=False)

        return df_mi

    return get_mutual_info
# ==================================================================================
# CLASSES
# ==================================================================================
class BaseSplit:
    '''
    Data base class for ML
    
    :param data: Dataframe to work with
    :type data: pyspark.sql.DataFrame
    :param config: Settings of ML operations
    :type config: dict
    '''
    def __init__(self, data, config):
        '''
        Constructor Method
        '''
        self.data = data
        self.config = config
        self._train = None
        self._test = None
        self._val = None
  
    @property
    def train(self):
        return self._train
    
    @property
    def test(self):
        return self._test
    
    @property
    def val(self):
        return self._val

    @train.setter
    def train(self, df):
        if isinstance(df, pyspark.sql.DataFrame):
            try:
                self._train = df
            except (TypeError):
                exit('Couldn\'t set attribute')
        else:
            raise TypeError('Must be a Dataframe')
    
    @test.setter
    def test(self, df):
        if isinstance(df, pyspark.sql.DataFrame):
            try:
                self._test = df
            except (TypeError):
                exit('Couldn\'t set attribute')
        else:
            raise TypeError('Must be a Dataframe')
            
    @val.setter
    def val(self, df):
        if isinstance(df, pyspark.sql.DataFrame):
            try:
                self._val = df
            except (TypeError):
                exit('Couldn\'t set attribute')
        else:
            raise TypeError('Must be a Dataframe')
    
    
class SplitTrainTestVal(BaseSplit, supp.AuxML):
    '''
    Splits and sample tha data
    '''
    def __init__(self, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
    
    def split_train_val(self, df=None, part_date=None, qty_val=None):
        '''
        Split data into train and validation dataframe,
        where the last data is set to the second.

        :param df: Dataframe to be splited
        :type df: pyspark.sql.DataFrame
        :param part_date: Partition column with dates
        :type part_date: str
        :param qty_val: Quantity of months to be in validation
        :type qty_val: int
        :return: Dataframe splited between train and validation
        :rtype: pyspark.sql.DataFrame, pyspark.sql.DataFrame
        '''
        import pyspark.sql.functions as f

        if df is None:
            df = self.data
        if part_date is None:
            part_date = self.config['spine']['date_col']
        if qty_val is None:
            qty_val = self.config['n_months_val']
        
        dates = sorted(df.select(f.col(part_date)).distinct().collect())
        val_dates = [date[0] for date in dates[-qty_val:]]
        train_dates = [date[0] for date in dates if date[0] not in val_dates]

        logger.debug(f'Validation dates: {val_dates}')
        logger.debug(f'Train dates: {train_dates}')
        
        if len(train_dates) > 0:
            df_train = df.filter(~f.col(part_date).isin(val_dates))
            df_val = df.filter(f.col(part_date).isin(val_dates))
        else:
            df_train = df
            df_val = None

        self._train = df_train
        self._val = df_val
        
    def _get_prior_by_date(self, df, part_date, target_col, id_col):
        '''
        Calculates prior of target by dates in the data 

        :param df: Dataframe
        :type df: pyspark.sql.DataFrame
        :param part_date: Column that contains date information
        :type part_date: str
        :param target_col: Binary column with target information
        :type target_col: str
        :param id_col: Identification column to count over
        :type id_col: str
        :return: Dictionary containing date and calculated ratio
        :rtype: dict
        '''
        import pyspark.sql.functions as f
        
        # Qty of zeros and ones by month
        df_frac_0 = df.filter(f.col(target_col) == 0) \
                                .groupBy(f.col(part_date)) \
                                .agg(f.count(f.col(id_col)).alias('zeros_count'))

        df_frac_1 = df.filter(f.col(target_col) == 1) \
                                .groupBy(f.col(part_date)) \
                                .agg(f.count(f.col(id_col)).alias('ones_count'))

        # Join of counting
        df_frac = df_frac_0.join(df_frac_1, [part_date])

        # Ratio calculation, ones by total
        df_frac = df_frac.withColumn('prior', f.lit(f.col('ones_count')
                                            / (f.col('zeros_count') + f.col('ones_count'))))

        # Dictionary creation to stratify data
        dict_prior = df_frac.select(f.col(part_date), f.col('prior')).rdd.collectAsMap()

        return dict_prior    
    
    def split_train_test_bymonth(self, spark, df=None, part_date=None, target_col=None,
                                 id_col=None, train_size=None, prior_map=None,
                                 min_prior=None, factor_mult=None, shuffle=None,
                                 cache_freq=None):
        '''
        Split data between train and test datasets, if posible
        samples train using original or custom ratio between
        number of target and all observations (prior)

        :param spark: SparkSession
        :type spark: pyspark.sql.session.SparkSession
        :param df: Dataframe
        :type df: pyspark.sql.DataFrame
        :param part_date: Column that contains date information
        :type part_date: str
        :param target_col: Binary column with target information
        :type target_col: str
        :param id_col: Identification column, unique value to 
            distinguish between dataset
        :type id_col: str
        :param train_size: Set size of train dataframe
        :type train_size: float
        :param prior_map: Custom prior to try sample over,
            defaults to None
        :type prior_map: dict
        :param min_prior: Set minimum prior acceptable,
            defaults to None
        :type min_prior: float
        :param factor_mult: Set multiplier factor to prior
        :type factor_mult: float
        :param shuffle: Shuffle dataframe, defaults to False
        :type shuffle: bool
        :return: Original prior and new one used (by month)
        :rtype: dict
        '''
        import pyspark.sql.functions as f
        from functools import reduce
        from pyspark import StorageLevel

        if df is None:
            df = self._train
        if part_date is None:
            part_date = self.config['spine']['date_col']
        if target_col is None:
            target_col = self.config['spine']['target_col']
        if id_col is None:
            id_col = self.config['spine']['artf_id_col']
        if train_size is None:
            train_size = self.config['train_size']
        if min_prior is None:
            min_prior = self.config['min_prior']
        if factor_mult is None:
            factor_mult = self.config['factor_mult']
        if shuffle is None:
            shuffle = self.config['shuffle']
        if cache_freq is None:
            cache_freq = self.config['cache_freq']
        if prior_map is None:
            if self.config['prior_map'] is None:
                # Dictionary creation to stratify data
                prior_map = self._get_prior_by_date(df=df, part_date=part_date,
                                                    target_col=target_col,
                                                    id_col=id_col)
            else:
                prior_map = self.config['prior_map']
        logger.debug(f'Original prior: {prior_map}')

        # Split train test
        if train_size < 1: 
            dfs = []
            dates = df.select(f.col(part_date)).distinct().collect()
            for date in dates:
                df_samp = df.filter(f.col(part_date) == date[0])
                # Take a sample by month
                dictionary = {0: train_size, 1: train_size}
                df_samp = df_samp.sampleBy(target_col, fractions=dictionary, seed=2012)
                dfs.append(df_samp)

            # Union all generated dfs to create df_train
            df_train = reduce(lambda x, y: x.unionByName(y), dfs)
            #self._persist_df(df=df_train)
            df_train.persist().count()
            df_test = df.join(df_train, [id_col], how='leftanti')
            
            logger.debug(f'N row test: {df_test.persist().count()}')
            logger.debug(f'Before sampling - N rows train: {df_train.count()}')
        else:
            df_train = df
            df_test = None

        # Try to resample zero observations by month
        dfs = []
        dict_samp = {}
        for date, prior in prior_map.items():
            df_0_1 = df_train.filter(f.col(part_date) == date)
            size_0 = df_0_1.filter(f.col(target_col) == 0).count()
            size_1 = df_0_1.filter(f.col(target_col) == 1).count()

            prior = prior * factor_mult
            # Manualy set prior, higher value means less zeros in the sample
            if not (min_prior is None):
                if prior < min_prior:
                    prior = min_prior

            logger.debug('########################################################\n')
            logger.debug(f'Original number of zeros in df_train part {date}: ' + str(size_0))
            logger.debug(f'Prior part {date}: ' + str(prior))
            logger.debug('\n')

            # Check probability of do the sample
            n_0 = size_1 * (1 - prior) / prior
            frac = n_0 / size_0
            if frac <= 1:
                # DF with sampled 0
                dictionary = {0: frac, 1: 1}
                df_samp = df_0_1.sampleBy(target_col, fractions = dictionary, seed=2012)
                logger.debug(f'New number of zeros in df_train part {date}: ' + str(round(n_0, 0)))
                # Prevent Spark Error
                df_samp = df_samp.coalesce(1)
            else:
                logger.debug(f'df_train part {date} kept same qty of 0s')
                # Prevent Spark Error
                df_samp = df_0_1.coalesce(1)
                prior = size_1 / (size_1 + size_0)

            dict_samp[date] = prior
            dfs.append(df_samp)

        logger.debug(f'New prior: {dict_samp}')
        # Join all data
        # df_train_samp = reduce(lambda x, y: x.unionByName(y), dfs)
        # To prevent Spark Error: Total size of serialized results of tasks
        # is bigger than spark.driver.maxResultSize
        df_train_samp = spark.createDataFrame([], schema=df.schema)   # empty df to append data into
        for i, dataframe in enumerate(dfs):
            df_train_samp = df_train_samp.unionByName(dataframe)
            if i % cache_freq == 0:
                # Action to cache in RAM and DISK intermediate results
                #df_train_samp.cache().count()
                df_train_samp.persist(StorageLevel.MEMORY_AND_DISK).count()

        if shuffle:
            df_train_samp = df_train_samp.sample(frac=1)
        
        self._train = df_train_samp
        self._test = df_test
        
        logger.debug(f'After sampling - N rows train: {self._train.persist().count()}')

        return prior_map, dict_samp

    def create_ind_split(self, indcol=None):
        '''
        Create flag to indicate which dataset
        the observation belongs to
        
        :param indcol: Columns name that indicates
            which dataset the observation belongs to
        :type indcol: str
        '''
        import pyspark.sql.functions as f

        if indcol is None:
            indcol = self.config['spine']['ind_split_col']

        self._train = self._train.withColumn(indcol, f.lit('train'))
        self._test = self._test.withColumn(indcol, f.lit('test'))
        self._val = self._val.withColumn(indcol, f.lit('val'))

    def get_joined_df(self):
        '''
        Joins all dataframes after the splitting
        '''
        from functools import reduce

        dfs = [self._train, self._test, self._val]
        df = reduce(lambda x, y: x.unionByName(y), dfs)

        return df


class ModelProcessor(BaseSplit, supp.AuxML):
    '''
    Wrapper to prepare data to modeling
    
    :param indxr: instance of pipeline
        with `pyspark.ml.feature.StringIndexer`
        as stages
    :type indxr: pyspark.ml.PipelineModel
    :param indxr_fitted: Fitted pipeline
        with `pyspark.ml.feature.StringIndexer`
        as stages
    :type indxr_fitted: Transformer
    :param ohe: instance of OHE
    :type ohe: pyspark.ml.feature.OneHotEncoderEstimator
    :param assembler: Instance of assembler
    :type assembler: pyspark.ml.feature.VectorAssembler
    :param model: Instance of Classification Model
    :type model: pyspark.ml.classification.`Model`
    :param feat_names: Variables to subset the dataframe,
        usually resulted from feature selection
    :type feat_names: list
    '''
    def __init__(self, indxr=None, indxr_fitted=None, ohe=None, ohe_fitted=None,
                 assembler=None, model=None, feat_names=None, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
        self.indxr = indxr
        self.indxr_fitted = indxr_fitted
        self.ohe = ohe
        self.ohe_fitted = ohe_fitted
        self.assembler = assembler
        self.model = model
        self.feat_names = feat_names
        
    def _get_categorical(self):
        '''
        Returns all categorical columns
        excepts if its in spine
        '''
        cat_cols = self._get_str_cols(self._train)
        cat_cols = [col for col in cat_cols if col not in self.config['spine'].values()]
        
        return cat_cols
    
    def _get_feat_names(self, df=None):
        '''
        Get a list of variables to feed into
        the assembler
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        '''
        if df is None:
            df = self._train
        
        self.feat_names = [x for x in df.columns if x not in self.config['spine'].values()]
        
        return self.feat_names
    
    def subset_data(self, df=None):
        '''
        Subset the dataset using features
        from feature selection
        
        :param df: Dataframe to analyze, defaults to None
        :type df: pyspark.sql.DataFrame
        '''
        keep_cols = list(self.config['spine'].values()) + self.feat_names 
        
        if df is None:
            df = self.data     
            self.data = df.select(*keep_cols)
        else:
            df = df.select(*keep_cols)
            
            return df
    
    def split_data(self, indcol=None):
        '''
        Split Main Df in train/test/validation
        
        :param indcol: Columns name that indicates
            which dataset the observation belongs to
        :type indcol: str
        '''
        import pyspark.sql.functions as f
        
        if indcol is None:
            indcol = self.config['spine']['ind_split_col']

        self._train = self.data.filter(f.col(indcol) == 'train')
        self._test = self.data.filter(f.col(indcol) == 'test')
        self._val = self.data.filter(f.col(indcol) == 'val')
        
    def fit_str_indexer(self):
        '''
        Fit StringIndexer to maps all string columns to
        columns of label indices
        '''
        from pyspark.ml import Pipeline
        from pyspark.ml.feature import StringIndexer
        
        cat_cols = self._get_categorical()
        
        # Indexing categorical columns
        indexers = [StringIndexer(inputCol=col, outputCol=col+'_idx', handleInvalid='keep') for col in cat_cols]

        # Pipeline of Indexers
        pipe_idx = Pipeline(stages=indexers)
        pipe_idx_fit = pipe_idx.fit(self._train)
        
        self.indxr = indexers
        self.indxr_fitted = pipe_idx_fit
    
    def fit_ohe(self):
        '''
        Fit OHE hot encoder for categorical variables
        '''
        from pyspark.ml.feature import OneHotEncoderEstimator
        
        input_ohe = [indexer.getOutputCol() for indexer in self.indxr]
        output_ohe = [indexer.getOutputCol()+'_OHE' for indexer in self.indxr]
        # handleInvalid='keep' -> New categories unseen in df_train will be all 0 in df_test
        ohe_encoder = OneHotEncoderEstimator(inputCols=input_ohe,
                                             outputCols=output_ohe,
                                             handleInvalid='keep',
                                             dropLast=False)
        
        ohe_encoder_fit = ohe_encoder.fit(self._train)
        
        self.ohe = ohe_encoder
        self.ohe_fitted = ohe_encoder_fit
   
    def transform_data(self, obj, split='pred'):
        '''
        Transforms data in the indexer
        
        :param obj: Fitted obj
        :type obj: Transformer
        :param split: Indicator to which dataset apply 
            the transformer, defaults to 'pred' (all data)
        :type split: str
        '''
        from pyspark.ml import Pipeline
        from pyspark.ml.feature import OneHotEncoderEstimator, StringIndexer, VectorAssembler
        from pyspark.ml.classification import GBTClassifier, RandomForestClassifier
        
        if obj == 'idx':
            obj = self.indxr_fitted
        elif obj == 'ohe':
            obj = self.ohe_fitted
        elif obj == 'model':
            obj = self.model
        elif obj == 'assembler':
            obj = self.assembler
        
        if split == 'train':
            self._train = obj.transform(self._train)
        elif split == 'test':
            self._test = obj.transform(self._test)
        elif split == 'val':
            self._val = obj.transform(self._val)
        else:
            self.data = obj.transform(self.data)        
 
    def get_dummies(self, split='pred'):
        '''
        Explode One Hot Encoding vector column, create 
        new binary columns - dummies.

        :param split: Indicator to which dataset apply 
            the transformer, defaults to 'pred' (all data)
        :type split: str
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        from pyspark.ml import Pipeline
        from pyspark.ml.feature import OneHotEncoder, StringIndexer

        if split == 'train':
            df = self._train
        elif split == 'test':
            df = self._test
        elif split == 'val':
            df = self._val
        else:
            df = self.data
        
        # Extract info
        ohe_encoding = []
        for str_idxr, ohe_col in zip(self.indxr_fitted.stages, self.ohe.getOutputCols()):
            # Iterate over labels
            for index, label in list(enumerate(str_idxr.labels)):
                ohe_encoding.append((ohe_col,   # Column containing Vector of OHE
                                     index,   # Position at vector
                                     str_idxr.getInputCol() + '_D_' + label))   # Column name

        # udf to extract vector and fill new cols
        func_ith = f.udf(lambda v, i: float(v[i]), t.FloatType())
        # Create exploded dataframe
        df = df.select(*[col for col in df.columns],
                       *[func_ith(data[0], f.lit(data[1])).astype(t.IntegerType()).alias(data[2])
                         for data in ohe_encoding])
        
        cat_cols = self._get_categorical()
        input_ohe = [str_idxr.getOutputCol() for str_idxr in self.indxr_fitted.stages]
        output_ohe = [str_idxr.getOutputCol()+'_OHE' for str_idxr in self.indxr_fitted.stages]
        df = df.drop(*cat_cols+input_ohe+output_ohe)
        
        if split == 'train':
            self._train = df
        elif split == 'test':
            self._test = df 
        elif split == 'val':
            self._val = df
        else:
            self.data = df

    def build_assembler(self, df=None):
        '''
        Merges multiple columns into a vector column
        '''
        from pyspark.ml.feature import VectorAssembler
        
        if df is None:
            df = self._train
        
        self._get_feat_names(df=df)
        
        assembler = VectorAssembler(inputCols=self.feat_names, outputCol='features', handleInvalid='skip')
        
        self.assembler = assembler
    
    def fit_model(self):
        '''
        Fit model using train data
        '''
        from pyspark.ml.classification import GBTClassifier, RandomForestClassifier
        
        model = self.model.fit(self._train)
        
        self.model = model


class FeatureSelector(ModelProcessor, supp.ReportManager):
    '''
    Holds Filter and Wrappers methods to
    get a better subset of variables
    '''
    def __init__(self, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
    
    def info_gain(self):
        '''
        Train a classification to get feat importance
        
        :return: Feature importance
        :rtype: pandas.DataFrame
        '''
        self.build_assembler()
        self.transform_data('assembler', split='train')
        self.fit_model()
        self.transform_data('model', split='train')
        pd_feat = self.get_feat_import(self.model, feat_names=self.feat_names)
        
        return pd_feat
        
    def chisqr_selctr(self, df=None, excpt_list=None, buckets=10, error=0.05, handler='error', **kwargs):
        '''
        ChiSquared selector for categorical and
        numerical features following suggestion
        of GC Models and Data.
        
        :param df: Dataframe
        :type df: pyspark.sql.DataFrame
        :param excpt_list: Variables to skip bucketizer
        :type excpt_list: list(str)
        :param buckets: Categories into which data points are grouped
        :type buckets: int
        :param error: Precision for the approximate
            quantile algorithm
        :type error: float
        :param handler: How to handle invalid entries
        :type handler: str
        :returns: Selected Features
        :rtype: pandas.DataFrame
        '''
        import numpy as np
        import pandas as pd
        from pyspark.ml import Pipeline
        from pyspark.ml.feature import ChiSqSelector, QuantileDiscretizer, VectorAssembler

        if df is None:
            df = self._train
        if excpt_list is None:
            excpt_list = self.config['spine'].values()
        
        num_cols = self._get_num_cols(df=df)
        num_cols = [col for col in num_cols if col not in excpt_list]

        bucketizer = Pipeline(stages=[QuantileDiscretizer(numBuckets=buckets,
                                                          relativeError=error,
                                                          handleInvalid=handler,
                                                          inputCol=col,
                                                          outputCol=col+'_bucket') for col in num_cols]).fit(df)
        df = bucketizer.transform(df)
        df = df.drop(*num_cols)
        
        self._train = df        
        self.build_assembler()
        self.transform_data('assembler', split='train')

        chisqr = ChiSqSelector(**kwargs)
        selector = chisqr.fit(self._train)
        
        chosen = [col.split('_bucket')[0] for col in np.array(self.feat_names)[selector.selectedFeatures]]
        pd_chosen = pd.DataFrame(chosen, columns=['feature'])

        return pd_chosen

    def cramers_v(self, df=None, excpt_list=None, target_col=None,
                  buckets=10, error=0.05, handler='error'):
        '''
        Calculate Cramer's V
       
        :param df: Dataframe to input
        :type df: pyspark.sql.DataFrame
        :param excpt_list: Variables to skip bucketizer
        :type excpt_list: list(str)
        :param target_col: Column name of target
        :type: str
        :param buckets: Categories into which data points are grouped
        :type buckets: int
        :param error: Precision for the approximate
            quantile algorithm
        :type error: float
        :param handler: How to handle invalid entries
        :type handler: str
        :return: Cramer's V statistic
        :rtype: pandas.DataFrame
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        from pyspark.ml import Pipeline
        from pyspark.ml.feature import QuantileDiscretizer

        if df is None:
            df = self._train
        if excpt_list is None:
            excpt_list = self.config['spine'].values()
        if target_col is None:    
            target_col = self.config['spine']['target_col']
        
        num_cols = self._get_num_cols(df=df)
        num_cols = [col for col in num_cols if col not in excpt_list]

        bucketizer = Pipeline(stages=[QuantileDiscretizer(numBuckets=buckets,
                                                          relativeError=error,
                                                          handleInvalid=handler,
                                                          inputCol=col,
                                                          outputCol=col+'_bucket') for col in num_cols]).fit(df)

        df = bucketizer.transform(df)
        df = df.drop(*num_cols)
        
        self._get_feat_names(df=df)
        df = df.select(*self.feat_names+[self.config['spine']['target_col']])        
        
        func_get_cramer = wrapper_get_cramer(target_col)
        logger.debug(func_get_cramer)
        input_df = df.withColumn('group', f.lit(1))
        output_df = input_df.groupBy('group').apply(func_get_cramer)
        pd_cramer = output_df.toPandas()
        pd_cramer.columns = pd_cramer.columns.str.replace(r'_bucket$', '')        
        
        return pd_cramer

    def mutual_infortn(self, df=None, target_col=None):
        '''
        Calculates Mutual Information
        
        :param df: Dataframe to input
        :type df: pyspark.sql.DataFrame
        :param target_col: Column name of target
        :type: str
        :return: Mutual information
        :rtype: pandas.DataFrame
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        if df is None:
            df = self._train
        if target_col is None:    
            target_col = self.config['spine']['target_col']
        
        self._get_feat_names(df=df)
        df = df.select(*self.feat_names+[self.config['spine']['target_col']])
         
        func_get_mtinfo = wrapper_get_mutual_info(target_col)
        logger.debug(func_get_mtinfo)
        input_df = df.withColumn('group', f.lit(1))
        output_df = input_df.groupBy('group').apply(func_get_mtinfo)
        pd_mi = output_df.toPandas()
        
        return pd_mi
    
class Fitter(ModelProcessor):
    '''
    Wrapper represeting modeling stage
    '''
    def __init__(self, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
    
    def train_transform_model(self):
        '''
        Train a model using train data
        '''
        self.build_assembler()
        
        logger.debug(self.model)
        self.transform_data('assembler', split='train')
        self.fit_model()
        self.transform_data('model', split='train')
        
class Scorer(ModelProcessor):
    '''
    Score Predictions
    '''
    def __init__(self, *args, **kwargs):
        '''
        Constructor Method
        '''
        super().__init__(*args, **kwargs)
        
    def wrapper_func_ith(self, v, i):
        '''
        Wrappper UDF to extract vector from
        array column
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        func_ith = f.udf(lambda v, i: float(v[i]), t.FloatType())
        
        return func_ith(v, i)
    
    def score_proba(self, split=None, proba_col='probability', score_name=None):
        '''
        Calcs score from probability of True target label

        :param split: Indicator to which dataset apply 
            the transformer, defaults to 'pred' (all data)
        :type split: str
        :param proba_col: Name of probability column,
            defaults to "probability"
        :type proba_col: str
        :param score_name: Name of new score column
        :type score_name: str
        :return: Dataframe with scores
        :rtype: pyspark.sql.DataFrame
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        if split == 'train':
            df = self._train
        elif split == 'test':
            df = self._test
        elif split == 'val':
            df = self._val
        else:
            df = self.data
            
        if score_name is None:
            score_name = self.config['score_col']
        
        df = df.withColumn(score_name, self.wrapper_func_ith(f.col(proba_col), f.lit(1)))
        df = df.withColumn(score_name, f.col(score_name) * f.lit(100))
        
        if split == 'train':
            self._train = df
        elif split == 'test':
            self._test = df 
        elif split == 'val':
            self._val = df
        else:
            self.data = df            

    def score_logit(self, split=None, proba_col='probability', score_name=None):
        '''
        Calcs score from probability of True target label

        :param split: Indicator to which dataset apply 
            the transformer, defaults to 'pred' (all data)
        :type split: str
        :param proba_col: Name of probability column,
            defaults to "probability"
        :type proba_col: str
        :param score_name: Name of new score column
        :type score_name: str
        :return: Dataframe with scores
        :rtype: pyspark.sql.DataFrame
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        
        if split == 'train':
            df = self._train
        elif split == 'test':
            df = self._test
        elif split == 'val':
            df = self._val
        else:
            df = self.data
        
        if score_name is None:
            score_name = self.config['score_col']
        
        df = df.withColumn('proba_1', self.wrapper_func_ith(f.col(proba_col), f.lit(1)))
        df = df.withColumn(score_name, f.round(f.log(f.col('proba_1') / (f.lit(1) - f.col('proba_1')))
                                         * f.lit(100) + f.lit(500), 0).cast(t.IntegerType()))
        df = df.drop(f.col('proba_1'))
        
        if split == 'train':
            self._train = df
        elif split == 'test':
            self._test = df 
        elif split == 'val':
            self._val = df
        else:
            self.data = df
    
    def get_percentiles(self, split=None, score_name=None, error=None,
                        buckets=None, buckets_name=None):
        '''
        Calculates each percentile each observation belongs to
        
        :param split: Indicator to which dataset apply 
            the transformer, defaults to 'pred' (all data)
        :type split: str
        :param score_name: Name of score column
        :type score_name: str
        :param error: The relative target precision when 
            calculating deciles
        :type error: float
        :param buckets: Number of bins to discretize
        :type buckets: float
        :param buckets_name: Number of bins to discretize
        :type buckets_name: str
        '''
        import pyspark.sql.functions as f
        import pyspark.sql.types as t
        from pyspark.ml.feature import QuantileDiscretizer
        from pyspark.sql import Window
        
        if split == 'train':
            df = self._train
        elif split == 'test':
            df = self._test
        elif split == 'val':
            df = self._val
        else:
            df = self.data
        
        if score_name is None:
            score_name = self.config['score_col']
        if error is None:
            error = self.config['eval']['error']
        if buckets is None:
            buckets = self.config['eval']['buckets']
        if buckets_name is None:
            buckets_name = self.config['buckets_name']
        
        df = df.withColumn('jitter', f.row_number().over(Window.orderBy(f.col(score_name).desc(), f.rand(seed=2012))))

        discretizer = QuantileDiscretizer(numBuckets=buckets,
                                          inputCol='jitter',
                                          outputCol=buckets_name,
                                          relativeError=error,
                                          handleInvalid='error')
        df = discretizer.fit(df).transform(df)
        df = df.withColumn(buckets_name, (f.col(buckets_name) + 1).cast(t.IntegerType())) \
                                                                  .drop(f.col('jitter'))
        
        if split == 'train':
            self._train = df
        elif split == 'test':
            self._test = df 
        elif split == 'val':
            self._val = df
        else:
            self.data = df